-- DropIndex
DROP INDEX "payment_id_invoice_key";
